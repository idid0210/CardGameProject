package login.run;

import login.view.FirstMain;

public class RunProgram {

	public static void main(String[] args) {
		new FirstMain();
	}

}
