package play.multi;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;

import java.awt.event.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.event.*;

import login.view.FirstMain;
import login.view.LoginNickName;
import login.view.NicknameDialog;

public class MultiGameDisplay extends JFrame implements ActionListener, Runnable {
	private JButton[] card = new JButton[24];
	private JButton start, exit;
	private JLabel myScoreLabel, myScoreLabel2;
	private JLabel otherScoreLabel;
	private int score=0;
	private JPanel gamePane, rightPane, btnPane, scorePane;
	private ImageIcon imageIcon[]=new ImageIcon[20] ;			// 앞면 이미지 저장할 20개 아이콘들
	
	private String ip = "192.168.30.78", nik;
	private Socket server;
	private final int port = 5252;
	private PrintWriter pw;                 
	private BufferedReader br; 
	
	public MultiGameDisplay(){}

	public MultiGameDisplay(String userNick) {
		nik = userNick;
	
		System.out.println("멀티게임실행");

		this.setTitle("카드 짝맞추기 - 멀티게임");
		this.setBounds(new Rectangle(50,50,1100,800));
		this.setLayout(null);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE); // 창 닫을때 프로그램 종료시킴

		 
		//게임 부분
		gamePane = new JPanel(new GridLayout(4,6));
		gamePane.setBounds(0,0,800,760);
		
		
		for(int i=0; i<card.length; i++){
			card[i] = new JButton(new ImageIcon("images/화투 그림/"+(i+1)+ ".jpg"));
			gamePane.add(card[i]);
		}
		
		
		//스코어,버튼 부분
		rightPane = new JPanel(new BorderLayout());
		scorePane = new JPanel();
		GridLayout grid = new GridLayout(2, 1);
		btnPane = new JPanel(grid);
		myScoreLabel = new JLabel(userNick + "님의 점수 : ");
		
		
		
		start = new JButton("게임시작");
		exit = new JButton("나가기");
		
		
		rightPane.setBounds(830, 20, 225,720);
		
		scorePane.setPreferredSize(new Dimension(200, 200));	
		scorePane.setBackground(Color.WHITE);
		scorePane.setBorder(BorderFactory.createLoweredBevelBorder()); //스코어부분 테두리 bevelBorder
		scorePane.add(myScoreLabel);
		
		btnPane.setPreferredSize(new Dimension(200, 100));
		
		start.setPreferredSize(new Dimension(60, 50));
		grid.setVgap(23);
		
		exit.addActionListener(this);
	
		
		rightPane.add(scorePane, BorderLayout.NORTH);
		rightPane.add(btnPane, BorderLayout.SOUTH);
		
		btnPane.add(start);
		btnPane.add(exit);
		
		this.add(gamePane, BorderLayout.WEST);
		this.add(rightPane, BorderLayout.EAST);
		
		this.setVisible(true);

	}

	

	@Override
	public void actionPerformed(ActionEvent event) {
		switch (event.getActionCommand()) {
		case "게임시작":
			
			break;
		case "나가기":
			int result = JOptionPane.showConfirmDialog(getParent(), "메인화면으로 돌아가시겠습니까?", "게임 나가기",
					JOptionPane.YES_NO_OPTION);
			if (result == 0){
				new FirstMain();
				this.setVisible(false);
			}
				break;
		}

	}
	
	/*public void userNick(String userNick, String otherNick){

		myScoreLabel = new JLabel(userNick+"님의 점수 : ");
		myScoreLabel2 = new JLabel(otherNick + "님의 점수 : ");
		scorePane.add(myScoreLabel);
		scorePane.add(myScoreLabel2);

	}*/

	@Override
	public void run() {
		try {
			server = new Socket(ip, port);

			br = new BufferedReader(new InputStreamReader(server.getInputStream()));
			pw = new PrintWriter(new OutputStreamWriter(server.getOutputStream()));
			
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			pw.write(nik + "\n");
			pw.flush();
			
			String nickName = br.readLine();
			System.out.println(nickName);
//			scorePane.add(new JLabel(nickName + "님의 점수 : "));
			myScoreLabel.setText(myScoreLabel.getText() + nickName );
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}