package run;

import java.io.*;
import java.net.*;
import java.util.*;

import controller.ClientHandler;

public class RunServer {
	public RunServer(){}
	
	public static final int port = 5252; //포트번호 생성
	public Vector<Socket> clients = new Vector<Socket>();
	
	public static void main(String[] args){
		RunServer rServer = new RunServer();
		ServerSocket server;
		try {
			server = new ServerSocket(port); //서버용 소켓객체 생성
			
			while (true) { //클라이언트가 연결을 요청할 때까지 기다림
				Socket client = server.accept(); //연결을 요청한 클라이언트의 요청 수락함
				rServer.clients.addElement(client);
				
				Thread aa = new ClientHandler(rServer, client);
				aa.start();
				
				System.out.println(aa.getName());
				
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void displayMsg(String clientMessage){
		System.out.println(clientMessage);
	}
	
	public Vector<Socket> getClients(){
		return clients;
	}
}
