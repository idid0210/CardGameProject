package run;

import view.FirstMain;

public class RunClient {

	public static void main(String[] args) {
		new FirstMain();
	}

}

